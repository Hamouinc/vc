---
id: 1
title: "Breaking Bad"
description: "A high school chemistry teacher diagnosed with inoperable lung cancer turns to manufacturing and selling methamphetamine in order to secure his family's future."
poster: "/placeholder.svg?height=400&width=300"
backdrop: "/placeholder.svg?height=400&width=1200"
rating: 9.5
genre: "Drama"
year: 2008
duration: "49m"
cast: 
  - "Bryan Cranston"
  - "Aaron Paul"
  - "Anna Gunn"
  - "Dean Norris"
creators: 
  - "Vince Gilligan"
seasons:
  - number: 1
    episodes: 7
    description: "The first season of Breaking Bad introduces Walter White, a high school chemistry teacher who is diagnosed with lung cancer and turns to a life of crime."
  - number: 2
    episodes: 13
    description: "In the second season, Walt and Jesse face new challenges as their drug operation expands, leading to unforeseen consequences."
  - number: 3
    episodes: 13
    description: "The third season sees Walt and Jesse's partnership tested as they face new adversaries and personal struggles."
  - number: 4
    episodes: 13
    description: "In the fourth season, Walt's transformation into his alter ego 'Heisenberg' continues as he faces off against a new, dangerous opponent."
  - number: 5
    episodes: 16
    description: "The fifth and final season brings Walt's story to its conclusion as his actions catch up with him and those around him."
---

"Breaking Bad" is a critically acclaimed crime drama series that follows Walter White, a high school chemistry teacher who is diagnosed with inoperable lung cancer. Desperate to secure his family's financial future before he dies, Walt turns to a life of crime, partnering with a former student to produce and sell crystal meth.

As the series progresses, Walt transforms from a mild-mannered teacher into a dangerous drug lord known as "Heisenberg." The show explores themes of morality, family, and the consequences of one's actions, set against the backdrop of Albuquerque, New Mexico's drug trade.

With its complex characters, intense plotlines, and stellar performances, "Breaking Bad" is widely regarded as one of the greatest television series of all time, earning numerous awards and accolades throughout its five-season run.

