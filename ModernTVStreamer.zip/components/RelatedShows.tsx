import ShowCard from './ShowCard'

const relatedShows = [
  { id: 2, title: "Better Call Saul", poster: "/placeholder.svg?height=400&width=300", rating: 8.9, genre: "Crime" },
  { id: 3, title: "Ozark", poster: "/placeholder.svg?height=400&width=300", rating: 8.4, genre: "Crime" },
  { id: 4, title: "Narcos", poster: "/placeholder.svg?height=400&width=300", rating: 8.8, genre: "Crime" },
  { id: 5, title: "The Wire", poster: "/placeholder.svg?height=400&width=300", rating: 9.3, genre: "Crime" },
]

export default function RelatedShows() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
      {relatedShows.map(show => (
        <ShowCard key={show.id} show={show} />
      ))}
    </div>
  )
}

