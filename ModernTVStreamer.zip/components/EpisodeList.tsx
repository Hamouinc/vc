"use client"

import { useState } from 'react'
import { ChevronDown, ChevronUp } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

interface Season {
  number: number;
  episodes: number;
  description: string;
}

interface EpisodeListProps {
  seasons: Season[];
}

export default function EpisodeList({ seasons }: EpisodeListProps) {
  const [expandedSeason, setExpandedSeason] = useState<number | null>(null)

  const toggleSeason = (seasonNumber: number) => {
    setExpandedSeason(expandedSeason === seasonNumber ? null : seasonNumber)
  }

  return (
    <Accordion type="single" collapsible className="w-full">
      {seasons.map((season) => (
        <AccordionItem key={season.number} value={`season-${season.number}`}>
          <AccordionTrigger>
            <div className="flex justify-between items-center w-full">
              <span>Season {season.number}</span>
              <span className="text-sm text-gray-500">{season.episodes} episodes</span>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <p className="mb-4">{season.description}</p>
            <Button variant="outline" size="sm">View All Episodes</Button>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  )
}

