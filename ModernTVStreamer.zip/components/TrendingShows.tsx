"use client"

import { useState } from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from "@/components/ui/button"

interface Show {
  id: number;
  title: string;
  poster: string;
  rating: number;
  genre: string;
}

interface TrendingShowsProps {
  shows: Show[];
}

export default function TrendingShows({ shows }: TrendingShowsProps) {
  const [startIndex, setStartIndex] = useState(0)

  const nextSlide = () => {
    setStartIndex((prev) => (prev + 1) % shows.length)
  }

  const prevSlide = () => {
    setStartIndex((prev) => (prev - 1 + shows.length) % shows.length)
  }

  const visibleShows = [...shows.slice(startIndex), ...shows.slice(0, startIndex)].slice(0, 5)

  return (
    <section className="mb-8">
      <h2 className="text-2xl font-bold mb-4">Trending Now</h2>
      <div className="relative">
        <div className="flex space-x-4 overflow-hidden">
          {visibleShows.map((show) => (
            <div key={show.id} className="flex-none w-1/5">
              <Image
                src={show.poster}
                alt={show.title}
                width={300}
                height={400}
                className="rounded-lg shadow-lg transition-transform duration-300 hover:scale-105"
              />
              <p className="mt-2 text-center">{show.title}</p>
            </div>
          ))}
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-0 top-1/2 transform -translate-y-1/2"
          onClick={prevSlide}
        >
          <ChevronLeft className="h-8 w-8" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-0 top-1/2 transform -translate-y-1/2"
          onClick={nextSlide}
        >
          <ChevronRight className="h-8 w-8" />
        </Button>
      </div>
    </section>
  )
}

