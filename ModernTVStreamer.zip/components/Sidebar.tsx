"use client"

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, PlayCircle, Compass, Heart, Clock, Settings } from 'lucide-react'

const menuItems = [
  { icon: Home, label: 'Home', href: '/' },
  { icon: PlayCircle, label: 'Shows', href: '/shows' },
  { icon: Compass, label: 'Discover', href: '/discover' },
  { icon: Heart, label: 'My List', href: '/my-list' },
  { icon: Clock, label: 'Watch Later', href: '/watch-later' },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="w-64 bg-card text-card-foreground">
      <div className="p-4">
        <h1 className="text-2xl font-bold text-primary mb-4">StreamFlix</h1>
        <nav>
          <ul>
            {menuItems.map((item) => (
              <li key={item.href} className="mb-2">
                <Link
                  href={item.href}
                  className={`flex items-center p-2 rounded-lg hover:bg-accent hover:text-accent-foreground transition-colors ${
                    pathname === item.href ? 'bg-accent text-accent-foreground' : ''
                  }`}
                >
                  <item.icon className="mr-2 h-5 w-5" />
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      <div className="absolute bottom-0 w-full p-4">
        <Link
          href="/settings"
          className="flex items-center p-2 rounded-lg hover:bg-accent hover:text-accent-foreground transition-colors"
        >
          <Settings className="mr-2 h-5 w-5" />
          Settings
        </Link>
      </div>
    </aside>
  )
}

