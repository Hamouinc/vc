"use client"

import { useState } from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from "@/components/ui/button"

const heroShows = [
  {
    id: 1,
    title: "Stranger Things",
    description: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces, and one strange little girl.",
    image: "/placeholder.svg?height=600&width=1200",
  },
  {
    id: 2,
    title: "The Crown",
    description: "This drama follows the political rivalries and romance of Queen Elizabeth II's reign and the events that shaped the second half of the 20th century.",
    image: "/placeholder.svg?height=600&width=1200",
  },
  {
    id: 3,
    title: "Bridgerton",
    description: "The eight close-knit siblings of the Bridgerton family look for love and happiness in London high society.",
    image: "/placeholder.svg?height=600&width=1200",
  },
]

export default function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % heroShows.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + heroShows.length) % heroShows.length)
  }

  return (
    <div className="relative mb-8 h-[400px] md:h-[600px]">
      {heroShows.map((show, index) => (
        <div
          key={show.id}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <Image
            src={show.image}
            alt={show.title}
            fill
            style={{ objectFit: 'cover' }}
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
          <div className="absolute bottom-0 left-0 p-8">
            <h2 className="text-4xl font-bold mb-2">{show.title}</h2>
            <p className="text-lg mb-4">{show.description}</p>
            <Button size="lg">Watch Now</Button>
          </div>
        </div>
      ))}
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-4 top-1/2 transform -translate-y-1/2"
        onClick={prevSlide}
      >
        <ChevronLeft className="h-8 w-8" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        className="absolute right-4 top-1/2 transform -translate-y-1/2"
        onClick={nextSlide}
      >
        <ChevronRight className="h-8 w-8" />
      </Button>
    </div>
  )
}

