"use client"

import { useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { Play, Plus, ThumbsUp } from 'lucide-react'
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface Show {
  id: number;
  title: string;
  poster: string;
  rating: number;
  genre: string;
}

interface ShowCardProps {
  show: Show;
}

export default function ShowCard({ show }: ShowCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <Card 
      className="overflow-hidden relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <CardContent className="p-0">
        <Link href={`/shows/${show.id}`}>
          <Image 
            src={show.poster} 
            alt={`${show.title} Poster`} 
            width={300} 
            height={400} 
            className="w-full h-auto transition-transform duration-300 ease-in-out transform hover:scale-110"
          />
        </Link>
        {isHovered && (
          <div className="absolute inset-0 bg-black bg-opacity-70 flex flex-col justify-between p-4 transition-opacity duration-300">
            <div>
              <h3 className="text-lg font-bold mb-2">{show.title}</h3>
              <p className="text-sm mb-2">Rating: {show.rating}/10</p>
              <p className="text-sm">{show.genre}</p>
            </div>
            <div className="flex justify-between">
              <Button size="sm" className="w-full mr-2">
                <Play className="mr-2 h-4 w-4" /> Play
              </Button>
              <Button size="sm" variant="outline" className="w-10 flex-shrink-0">
                <Plus className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="outline" className="w-10 flex-shrink-0">
                <ThumbsUp className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

