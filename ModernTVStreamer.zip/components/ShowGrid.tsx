import ShowCard from './ShowCard'

interface Show {
  id: number;
  title: string;
  poster: string;
  rating: number;
  genre: string;
}

interface ShowGridProps {
  title: string;
  shows: Show[];
}

export default function ShowGrid({ title, shows }: ShowGridProps) {
  return (
    <section className="mb-8">
      <h2 className="text-2xl font-bold mb-4">{title}</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {shows.map(show => (
          <ShowCard key={show.id} show={show} />
        ))}
      </div>
    </section>
  )
}

