import ShowGrid from '@/components/ShowGrid'
import { getAllShows } from '@/lib/api'

export default function MyListPage() {
  // In a real application, you would fetch the user's list from a database
  const myList = getAllShows(['id', 'title', 'poster', 'rating', 'genre']).slice(0, 4)

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">My List</h1>
      {myList.length > 0 ? (
        <ShowGrid title="My List" shows={myList} />
      ) : (
        <p>Your list is empty. Add shows to your list to see them here.</p>
      )}
    </div>
  )
}

