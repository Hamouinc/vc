import ShowGrid from '@/components/ShowGrid'
import { getAllShows } from '@/lib/api'

export default function DiscoverPage() {
  const allShows = getAllShows(['id', 'title', 'poster', 'rating', 'genre'])

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Discover New Shows</h1>
      <ShowGrid title="Recommended for You" shows={allShows.slice(0, 6)} />
      <ShowGrid title="Popular in Your Area" shows={allShows.slice(6, 12)} />
    </div>
  )
}

