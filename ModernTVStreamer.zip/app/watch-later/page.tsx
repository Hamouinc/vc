import ShowGrid from '@/components/ShowGrid'
import { getAllShows } from '@/lib/api'

export default function WatchLaterPage() {
  // In a real application, you would fetch the user's watch later list from a database
  const watchLater = getAllShows(['id', 'title', 'poster', 'rating', 'genre']).slice(0, 3)

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Watch Later</h1>
      {watchLater.length > 0 ? (
        <ShowGrid title="Watch Later" shows={watchLater} />
      ) : (
        <p>Your watch later list is empty. Add shows to watch later to see them here.</p>
      )}
    </div>
  )
}

