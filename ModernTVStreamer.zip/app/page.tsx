import HeroCarousel from '@/components/HeroCarousel'
import ShowGrid from '@/components/ShowGrid'
import TrendingShows from '@/components/TrendingShows'
import { getAllShows } from '@/lib/api'

export default function Home() {
  const allShows = getAllShows(['id', 'title', 'poster', 'rating', 'genre'])

  return (
    <div className="container mx-auto px-4 py-8">
      <HeroCarousel />
      <TrendingShows shows={allShows.slice(0, 5)} />
      <ShowGrid title="Popular Shows" shows={allShows.slice(0, 6)} />
      <ShowGrid title="New Releases" shows={allShows.slice(6, 12)} />
    </div>
  )
}

