import ShowGrid from '@/components/ShowGrid'
import { getAllShows } from '@/lib/api'

export default function ShowsPage() {
  const allShows = getAllShows(['id', 'title', 'poster', 'rating', 'genre'])

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">All Shows</h1>
      <ShowGrid title="All Shows" shows={allShows} />
    </div>
  )
}

