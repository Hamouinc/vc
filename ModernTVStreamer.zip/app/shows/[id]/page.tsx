import Image from 'next/image'
import { notFound } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import EpisodeList from '@/components/EpisodeList'
import RelatedShows from '@/components/RelatedShows'
import { getShowBySlug, getAllShows } from '@/lib/api'

export async function generateStaticParams() {
  const shows = getAllShows(['slug'])

  return shows.map((show) => ({
    slug: show.slug,
  }))
}

export default function ShowPage({ params }: { params: { id: string } }) {
  const show = getShowBySlug(params.id, [
    'title',
    'poster',
    'backdrop',
    'rating',
    'genre',
    'year',
    'duration',
    'summary',
    'cast',
    'creators',
    'seasons',
    'content'
  ])

  if (!show) {
    notFound()
  }

  return (
    <div>
      <div className="relative h-[400px]">
        <Image
          src={show.backdrop}
          alt={`${show.title} Backdrop`}
          fill
          style={{ objectFit: 'cover' }}
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
      </div>
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8 -mt-32 relative z-10">
          <div className="md:w-1/3">
            <Image
              src={show.poster}
              alt={`${show.title} Poster`}
              width={400}
              height={600}
              className="rounded-lg shadow-lg"
            />
          </div>
          <div className="md:w-2/3">
            <h1 className="text-4xl font-bold mb-4">{show.title}</h1>
            <div className="flex gap-4 mb-4 text-sm">
              <span>{show.year}</span>
              <span>{show.duration}</span>
              <span>{show.genre}</span>
              <span>Rating: {show.rating}/10</span>
            </div>
            <p className="text-lg mb-4">{show.summary}</p>
            <div className="mb-4">
              <h3 className="font-bold mb-2">Cast:</h3>
              <p>{show.cast.join(', ')}</p>
            </div>
            <div className="mb-4">
              <h3 className="font-bold mb-2">Creators:</h3>
              <p>{show.creators.join(', ')}</p>
            </div>
            <div className="flex gap-4">
              <Button size="lg">
                Play
              </Button>
              <Button size="lg" variant="outline">
                Add to My List
              </Button>
            </div>
          </div>
        </div>
        <Tabs defaultValue="episodes" className="mt-8">
          <TabsList>
            <TabsTrigger value="episodes">Episodes</TabsTrigger>
            <TabsTrigger value="related">Related Shows</TabsTrigger>
          </TabsList>
          <TabsContent value="episodes">
            <EpisodeList seasons={show.seasons} />
          </TabsContent>
          <TabsContent value="related">
            <RelatedShows />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

